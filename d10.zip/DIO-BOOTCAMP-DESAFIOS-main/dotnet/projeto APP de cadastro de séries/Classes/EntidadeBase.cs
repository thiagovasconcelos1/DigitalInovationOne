namespace Dio.Series.Classes
{
    public class EntidadeBase
    {
        
    }
}