
  <!--Banner session-->
<p align="center">
  <img src="./assets/banner.png" alt="DIO" tittle="Digital Innovation One">
</p>


<!--About session-->
<h1 align="center">Desafios dos Bootcamps da Digital Innovation One</h1>

Algumas dos aprendizados na [Digital Innovation One](https://digitalinnovation.one/).
 
 <!--icons session-->
   <!-- C -->
<p align="left">
  <a href="https://github.com/vasconcelostac/DIO-BOOTCAMP-DESAFIOS/tree/main/C%23" <a/> 
  <img src="assets/c1.png "c1" tittle="c1" height="134" width="150">
  <a href="https://github.com/vasconcelostac/DIO-BOOTCAMP-DESAFIOS/tree/main/dotnet"<a/>                                                                 
   <img src="assets/.net.png "c1" tittle="c1" height="134" width="150">                                                          
</p>
                                                                                                                                                                                                    
 <!--summary-->                                                                                                                                 
<h3> Códigos | Codes </h3>
 <!--C#-->                                                
 <details>                                        
   <div>
    <h4>Desafios matemáticos básicos | Basic Math Challenges</h4>
    <a href="https://github.com/vasconcelostac/DIO-BOOTCAMP-DESAFIOS/blob/109963840f652eb32697ed3a7777e818bfb07882/C%23/Desafios%20matem%C3%A1ticos%20b%C3%A1sicos/SIMPLES%20SOMA.cs">Simples soma | simple sum</a><br/>
    <a href="https://github.com/vasconcelostac/DIO-BOOTCAMP-DESAFIOS/blob/main/C%23/Desafios%20matem%C3%A1ticos%20b%C3%A1sicos/DDD.cs">Switch Case DDD</a><br/>
  </div> 
  <summary><span>C#</span></summary>  
  <p></p>
</details>

<!--.NET-->  
 <details> 
  <summary><span>.NET</span></summary>  
   <div>
     <h4>Projeto | Project APP</h4>
     <a href="https://github.com/vasconcelostac/DIO-BOOTCAMP-DESAFIOS/tree/main/dotnet/projeto%20APP%20de%20cadastro%20de%20s%C3%A9ries"> APP de cadastro de séries | Series registration APP</a><br/>
   </div>
</details>
                                                                                                                                      
